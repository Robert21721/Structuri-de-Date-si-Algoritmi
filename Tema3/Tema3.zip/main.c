#include "Functions.h"

int main(int argc, char *argv[])
{
    // daca numarul de argumente este mai mic decat 2
    // sau mai mare decat 3 intorc un cod de eroare
    if (argc < 2 || argc > 3) {
        exit(-1);
    }

    // deschid fisierele si creez graful g
    FILE *f_in, *f_out;
    f_in = fopen("blockdag.in", "rt");
    f_out = fopen("blockdag.out", "wt");
    TGraph *g = create_graph(f_in);
    fclose(f_in);

    // cerinta 1
    if (strcmp(argv[1], "-c1") == 0) {
        verify_ciclic_graph(f_out, g);
    }

    // cerinta 2
    if (strcmp(argv[1], "-c2") == 0) {
        int *v_past, *v_future, *v_anticone, *v_tips;

        // aflu indexul la care se afla nodul cu numele name
        char *name = argv[2];
        int i = get_idx(g, name);

        v_past = past(f_out, g->arr[i], g);
        v_future = future(f_out, g->arr[i], g, 1);
        v_anticone = anticone(f_out, v_past, v_future, g->arr[i], g);
        v_tips = tips(f_out, g);

        free(v_past);
        free(v_future);
        free(v_anticone);
        free(v_tips);
    }

    // cerinta 3
    if (strcmp(argv[1], "-c3") == 0) {

    }

    free_graph(g);
    fclose(f_out);
    return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 200

// structura unui nod din lista de adiacenta
typedef struct TNode {
    char *name;
    struct TNode *next;
} TNode;

// structura grafului
typedef struct {
    int no;
    TNode **arr;
} TGraph;